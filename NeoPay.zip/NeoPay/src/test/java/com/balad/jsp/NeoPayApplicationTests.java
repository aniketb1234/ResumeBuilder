package com.balad.jsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeoPayApplicationTests {

	@Test
	void contextLoads() {
	}

}
