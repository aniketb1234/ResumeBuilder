package com.balad.jsp.util;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class HMACAuthUtil {

    // HMAC SHA256 Algorithm
    private static final String HMAC_SHA256 = "HmacSHA256";

    // Generate Nonce (Random string)
    public static String generateNonce() {
        byte[] nonce = new byte[16];
        new Random().nextBytes(nonce);
        return Base64.encodeBase64String(nonce);
    }

    // Get current UNIX timestamp
    public static long getUnixTimestamp() {
        return System.currentTimeMillis() / 1000L;
    }

    // Generate Base64 encoded HMAC signature
    public static String generateSignature(String appId, String apiKey, String method, String requestUri, String nonce, String requestBody) throws Exception {
        long timestamp = getUnixTimestamp();

        // Hash the body using MD5 and encode as Base64
        String requestPayloadHash = "";
        if (requestBody != null && !requestBody.isEmpty()) {
            byte[] md5Hash = DigestUtils.md5(requestBody.getBytes(StandardCharsets.UTF_8));
            requestPayloadHash = Base64.encodeBase64String(md5Hash);
        }

        // Encode the URI
        String encodedUri = UriUtils.encodePath(requestUri.toLowerCase(), StandardCharsets.UTF_8.name());

        // Build the raw signature string (no delimiters)
        String signatureRawData = appId + method.toUpperCase() + encodedUri + timestamp + nonce + requestPayloadHash;

        // Create HMAC with SHA256
        Mac mac = Mac.getInstance(HMAC_SHA256);
        SecretKeySpec secretKey = new SecretKeySpec(apiKey.getBytes(StandardCharsets.UTF_8), HMAC_SHA256);
        mac.init(secretKey);

        // Sign the raw signature data and encode in Base64
        byte[] hmacData = mac.doFinal(signatureRawData.getBytes(StandardCharsets.UTF_8));
        String signature = Base64.encodeBase64String(hmacData);

        return signature;
    }

    // Example to build the Authorization header value
    public static String buildAuthorizationHeader(String appId, String signature, String nonce, long timestamp) {
        return "hmacauth " + appId + ":" + signature + ":" + nonce + ":" + timestamp;
    }
}
