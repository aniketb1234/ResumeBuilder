package com.balad.jsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.balad.jsp.service.HMACAuthService;

@RestController
@RequestMapping("/api")
public class HMACController {

    @Autowired
    private HMACAuthService hmacAuthService;

    @PostMapping("/sendGetEchoRequest")
    public ResponseEntity<String> sendGetEchoRequest(@RequestParam String agentSessionId) {
        try {
            String response = hmacAuthService.getEcho(agentSessionId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/getAgentList")
    public ResponseEntity<String> getAgentList(@RequestParam String agentSessionId,
                                               @RequestParam String paymentMode,
                                               @RequestParam String payoutCountry,
                                               @RequestParam String payoutCurrency) {
        try {
            String response = hmacAuthService.getAgentList(agentSessionId, paymentMode, payoutCountry, payoutCurrency);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/sendTransaction")
    public ResponseEntity<String> sendTransaction(@RequestBody String transactionRequest) {
        try {
            String response = hmacAuthService.sendTransaction(transactionRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/commitTransaction")
    public ResponseEntity<String> commitTransaction(@RequestParam String agentSessionId,
                                                    @RequestParam String confirmationId) {
        try {
            String response = hmacAuthService.commitTransaction(agentSessionId, confirmationId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/queryTransactionStatus")
    public ResponseEntity<String> queryTransactionStatus(@RequestParam String agentSessionId,
                                                         @RequestParam String pinNumber,
                                                         @RequestParam(required = false) String agentTxnId) {
        try {
            String response = hmacAuthService.queryTransactionStatus(agentSessionId, pinNumber, agentTxnId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/getExchangeRate")
    public ResponseEntity<String> getExchangeRate(@RequestBody String exchangeRateRequest) {
        try {
            String response = hmacAuthService.getExchangeRate(exchangeRateRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/getCatalogue")
    public ResponseEntity<String> getCatalogue(@RequestBody String catalogueRequest) {
        try {
            String response = hmacAuthService.getCatalogue(catalogueRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/reconcileReport")
    public ResponseEntity<String> reconcileReport(@RequestBody String reportRequest) {
        try {
            String response = hmacAuthService.reconcileReport(reportRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/cancelTransaction")
    public ResponseEntity<String> cancelTransaction(@RequestBody String cancelRequest) {
        try {
            String response = hmacAuthService.cancelTransaction(cancelRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/inquiryAccount")
    public ResponseEntity<String> inquiryAccount(@RequestBody String inquiryRequest) {
        try {
            String response = hmacAuthService.inquiryAccount(inquiryRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/checkBalance")
    public ResponseEntity<String> checkBalance(@RequestParam String agentSessionId) {
        try {
            String response = hmacAuthService.checkBalance(agentSessionId);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/amendTransaction")
    public ResponseEntity<String> amendTransaction(@RequestBody String amendRequest) {
        try {
            String response = hmacAuthService.amendTransaction(amendRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
