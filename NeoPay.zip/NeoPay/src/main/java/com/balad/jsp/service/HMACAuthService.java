package com.balad.jsp.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.balad.jsp.util.HMACAuthUtil;

@Service
public class HMACAuthService {

    private final String appId = "ALFANOW";
    private final String apiKey = "NWZiNzFjZmY4MDU3NGExZDgyN2ZmNWE0NzFhNGUwZTM="; 
    private final String baseUrl = "https://uat.neomoneytransfer.com/SendApi/api/webservice";

    // Utility method to send requests
    private String sendRequest(String url, String body) throws Exception {
        String method = "POST";

        String nonce = HMACAuthUtil.generateNonce();
        long timestamp = HMACAuthUtil.getUnixTimestamp();
        String signature = HMACAuthUtil.generateSignature(appId, apiKey, method, url, nonce, body);
        String authorizationHeader = HMACAuthUtil.buildAuthorizationHeader(appId, signature, nonce, timestamp);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorizationHeader);
        headers.set("Content-Type", "application/json");

        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            return "Error: " + response.getStatusCode();
        }
    }

    public String getEcho(String agentSessionId) throws Exception {
        String url = baseUrl + "/GetEcho";
        String body = "{\"agentSessionId\": \"" + agentSessionId + "\"}";
        return sendRequest(url, body);
    }

    public String getAgentList(String agentSessionId, String paymentMode, String payoutCountry, String payoutCurrency) throws Exception {
        String url = baseUrl + "/Getagentlist";
        String body = "{\"agentSessionId\": \"" + agentSessionId + "\", \"paymentMode\": \"" + paymentMode + "\", \"payoutCountry\": \"" + payoutCountry + "\", \"payoutCurrency\": \"" + payoutCurrency + "\"}";
        return sendRequest(url, body);
    }

    public String sendTransaction(String transactionRequest) throws Exception {
        String url = baseUrl + "/SendTransaction";
        return sendRequest(url, transactionRequest);
    }

    public String commitTransaction(String agentSessionId, String confirmationId) throws Exception {
        String url = baseUrl + "/CommitTransaction";
        String body = "{\"agentSessionId\": \"" + agentSessionId + "\", \"confirmationId\": \"" + confirmationId + "\"}";
        return sendRequest(url, body);
    }

    public String queryTransactionStatus(String agentSessionId, String pinNumber, String agentTxnId) throws Exception {
        String url = baseUrl + "/QueryTXNStatus";
        String body = "{\"agentSessionId\": \"" + agentSessionId + "\", \"pinNumber\": \"" + pinNumber + "\", \"agentTxnId\": \"" + agentTxnId + "\"}";
        return sendRequest(url, body);
    }

    public String getExchangeRate(String exchangeRateRequest) throws Exception {
        String url = baseUrl + "/GetEXRate";
        return sendRequest(url, exchangeRateRequest);
    }

    public String getCatalogue(String catalogueRequest) throws Exception {
        String url = baseUrl + "/GetCatalogue";
        return sendRequest(url, catalogueRequest);
    }

    public String reconcileReport(String reportRequest) throws Exception {
        String url = baseUrl + "/ReconcileReport";
        return sendRequest(url, reportRequest);
    }

    public String cancelTransaction(String cancelRequest) throws Exception {
        String url = baseUrl + "/CancelTransaction";
        return sendRequest(url, cancelRequest);
    }

    public String inquiryAccount(String inquiryRequest) throws Exception {
        String url = baseUrl + "/AccountValidation";
        return sendRequest(url, inquiryRequest);
    }

    public String checkBalance(String agentSessionId) throws Exception {
        String url = baseUrl + "/CheckBalance";
        String body = "{\"agentSessionId\": \"" + agentSessionId + "\"}";
        return sendRequest(url, body);
    }

    public String amendTransaction(String amendRequest) throws Exception {
        String url = baseUrl + "/AmendTransaction";
        return sendRequest(url, amendRequest);
    }
}
